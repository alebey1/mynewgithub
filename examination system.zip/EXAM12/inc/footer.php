 </section>
 <section class="footeroption">
 <a href="about us.txt" ><span style="float: left;color:white;">About us</a>
 <a href="admin/login.php" ><span style="color:white;">Admin Login</a>
 <a href="#" ><span style="float: right;color:white;">developers</a>
		<!--<h2><?php echo "Developed By Alemu Beyene"; ?></h2>
		<p>Email: alebeyene9@gmail.com </p>-->
	
	</section>
</div>
</body>
</html>